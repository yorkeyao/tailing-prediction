import csv
import matplotlib.pyplot as plt
import numpy as np

path = "/Users/zhangmengyan/Downloads/data-hydrosaver/train_file/"
file_in = path + "average_day.csv"
csv_reader = csv.reader(open(file_in))

rows = [row for row in csv_reader]
rows = np.mat(rows)
row_num , column_num = rows.shape
print column_num

for column in range(1, column_num):
    plt.figure(figsize=(20,10))
    plt.plot(rows[1:,0], rows[1:,column])
    plt.title(str(column) + ": " + str(rows[0, column]))
    plt.savefig(path + "ave_day_"+ str(column) + "_" + str(rows[0, column])+ ".png")
