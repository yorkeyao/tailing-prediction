import csv
import numpy as np

path = "/Users/zhangmengyan/Downloads/data-hydrosaver/train_file/"
file_in = path + "train_file_valid.csv"
file_out = path + "average_day.csv"

csv_reader = csv.reader(open(file_in))
csv_writer = csv.writer(open(file_out, 'wb'))

rows = [row for row in csv_reader]
#rows = np.mat(rows)
row_num, column_num = len(rows), len(rows[0])
#row_num, column_num = rows.shape
print row_num
print column_num

csv_writer.writerow(rows[0])

under_range = 0.0
up_range = 1440.0
ave_range = 1440  # 24*60 one day
sum_list = [0.0] * column_num
ave_list = [0.0] * column_num
largest_row_value = rows[-1][0]
count = 0

for row in rows[1:]:
    if float(row[0])>= under_range and float(row[0])< up_range:
        for column in range(column_num):
            sum_list[column] += float(row[column])
        count += 1
    else:
        print count
        for column in range(column_num):
            ave_list[column] = sum_list[column]/float(count)
        csv_writer.writerow(ave_list)
        count = 0
        #print row[0]
        for column in range(column_num):
            sum_list[column] = float(row[column])
        count += 1   
        if float(row[0]) < up_range + ave_range:
            under_range = up_range + 1  
            if under_range + ave_range <= largest_row_value:         
                up_range = under_range + ave_range
            else:
                up_range = largest_row_value
        else: 
            under_range = float(row[0])
            if under_range + ave_range <= largest_row_value:         
                up_range = under_range + ave_range
            else:
                up_range = largest_row_value
        assert under_range <= up_range
        print "underage: "+ str(under_range) + " uprage: " + str(up_range)

        
        

        
        
